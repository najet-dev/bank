package fr.najet.bank.enums;

public enum OperationType {
    DEBIT, CREDIT
}
