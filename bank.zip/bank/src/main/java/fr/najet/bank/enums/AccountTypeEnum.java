package fr.najet.bank.enums;

public enum AccountTypeEnum {
    CURRENTACCOUNT, SAVINGSACCOUNT;
}
